const { Client, GatewayIntentBits, Partials } = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

const TOKEN = "YOUR_BOT_TOKEN"; // ganti dengan token bot kamu
const MESSAGE_ID = "ID_MESSAGE"; // ID pesan target
const EMOJI = "✅";              // emoji untuk react
const ROLE_ID = "ID_ROLE";       // role yang akan diberikan

client.once("ready", () => {
  console.log(`✅ Bot sudah login sebagai ${client.user.tag}`);
});

client.on("messageReactionAdd", async (reaction, user) => {
  if (reaction.partial) await reaction.fetch();
  if (user.bot) return;
  if (reaction.message.id !== MESSAGE_ID) return;
  if (reaction.emoji.name !== EMOJI) return;

  const guild = reaction.message.guild;
  const member = await guild.members.fetch(user.id);
  await member.roles.add(ROLE_ID);
  console.log(`Role ditambahkan ke ${user.tag}`);
});

client.on("messageReactionRemove", async (reaction, user) => {
  if (reaction.partial) await reaction.fetch();
  if (user.bot) return;
  if (reaction.message.id !== MESSAGE_ID) return;
  if (reaction.emoji.name !== EMOJI) return;

  const guild = reaction.message.guild;
  const member = await guild.members.fetch(user.id);
  await member.roles.remove(ROLE_ID);
  console.log(`Role dihapus dari ${user.tag}`);
});

client.login(TOKEN);
